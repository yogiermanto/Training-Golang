package main

import (
	"Testing/handler"
	"net/http"
)

func main() {
	http.HandleFunc("/", handler.Register)
	http.ListenAndServe(":8061", nil)
}
