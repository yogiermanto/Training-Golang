package handler

import (
	"Testing/config"
	"fmt"
	"net/http"
)

func Register(w http.ResponseWriter, r *http.Request) {
	db, err := config.Connect()
	if err != nil {
		fmt.Println(err.Error())
		return
	}
	defer db.Close()

	if r.Method != "POST" {
		http.ServeFile(w, r, "views/register.html")
		return
	}

	nama := r.FormValue("nama")
	tanggallahir := r.FormValue("tanggallahir")
	berat := r.FormValue("berat")
	tinggi := r.FormValue("tinggi")
	alamat := r.FormValue("alamat")

	_, err = db.Exec("INSERT INTO murid(nama,alamat,tanggallahir,berat,tinggi) VALUES(?,?,?,?,?)",
		nama, tanggallahir, berat, tinggi, alamat)
	if err != nil {
		fmt.Println("Error")
	}
}
